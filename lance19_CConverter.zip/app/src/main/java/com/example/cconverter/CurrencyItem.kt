package com.example.cconverter

data class CurrencyItem(val flagId: Int, val currencyName: String, val rate: Double) {
}